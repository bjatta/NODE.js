/**
 * Created by Bjatta on 19.04.2017. from 09.06
 */
((sity1,sity2)=> {
    console.log('from § 09');
    let s1 = sity1;
    let s2 = sity2;
    console.log('s1:'+s1,'s2:'+s2);
    let t1=s2;
    let t2=s1;
console.log('t1:'+t1,'t2:'+t2);
})('Minsk','Brest');