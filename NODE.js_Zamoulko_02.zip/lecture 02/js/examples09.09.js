/**
 * Created by Bjatta on 19.04.2017. from 09.09
 */
((familyName1,familyName2)=> {
    console.log('first '+familyName1,'second: '+familyName2,'is first longer: ' + (familyName1.length > familyName2.length));
})('Zamoulko','Agdanskaja');