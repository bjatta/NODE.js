/**
 * Created by Bjatta on 19.04.2017. from 11.04
 */
((...vars)=> {
    let array12 = [];
    for (let i=0;i<13;i++) array12.push(Math.round(Math.random()*(190-163)+163));
    console.log('д',array12);array12.length=0;
})(1,2,3,4,5,6,7,8,9,0);