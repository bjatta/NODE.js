/**
 * Created by Bjatta on 19.04.2017. from 11.01
 */
(()=> {
    console.log('from § 11');
    let array8 = [37,0,50,46,34,46,0,13];
    console.log(array8);
})();