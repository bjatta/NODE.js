/**
 * Created by Bjatta on 19.04.2017. from 09.08
 */
((sityName1,sityName2)=> {
    console.log('name: '+sityName1,'chars: '+sityName1.length,'is even: '+!(sityName1.length%2));
    console.log('name: '+sityName2,'chars: '+sityName2.length,'is even: '+!(sityName2.length%2));
})('DneproPetrovsk','Minsk');