/**
 * Created by Bjatta on 19.04.2017. from 09.07
 */
((soccerClubName)=> {
    console.log('name: '+soccerClubName,'chars: '+soccerClubName.length);
})('MPCC');